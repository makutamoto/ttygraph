You can run ttygraph directory.
No more operation required.

If you need more information, visit https://github.com/makutamoto/ttygraph.
